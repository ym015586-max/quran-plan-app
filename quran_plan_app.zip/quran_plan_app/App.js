import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Alert,
  SafeAreaView,
  StatusBar
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const START_DATE = new Date(2026, 9, 6); // 06/10/2026

export default function App() {
  const [activeTab, setActiveTab] = useState('planTab');
  const [currentDay, setCurrentDay] = useState(1);
  const [lastCompletedDate, setLastCompletedDate] = useState('');
  const [history, setHistory] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const isDemoMode = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const start = new Date(START_DATE);
    start.setHours(0, 0, 0, 0);
    return today < start;
  };

  const loadData = async () => {
    try {
      if (!isDemoMode()) {
        const autoReset = await AsyncStorage.getItem('quran_autoreset_oct6');
        if (!autoReset) {
          await AsyncStorage.multiRemove(['quran_day', 'quran_last_date', 'quran_history']);
          await AsyncStorage.setItem('quran_autoreset_oct6', 'true');
        }
      }

      const savedDay = await AsyncStorage.getItem('quran_day');
      const savedDate = await AsyncStorage.getItem('quran_last_date');
      const savedHistory = await AsyncStorage.getItem('quran_history');

      if (savedDay) setCurrentDay(parseInt(savedDay));
      if (savedDate) setLastCompletedDate(savedDate);
      if (savedHistory) setHistory(JSON.parse(savedHistory));
    } catch (e) {
      console.error(e);
    }
  };

  const getDateForDay = (dayIndex) => {
    let d = new Date(START_DATE);
    d.setDate(d.getDate() + (dayIndex - 1));
    let dayStr = String(d.getDate()).padStart(2, '0');
    let monthStr = String(d.getMonth() + 1).padStart(2, '0');
    return `${dayStr}/${monthStr}/${d.getFullYear()}`;
  };

  const getTaskForDay = (day) => {
    if (day > 120) return "تمت الخطة بفضل الله!";
    let hzb1 = Math.ceil((day * 2) / 4);
    let q1 = ((day * 2) - 1) % 4 || 4;
    let q2 = (day * 2) % 4 || 4;
    let revHzb = 61 - Math.ceil(day / 2);
    if (revHzb < 1) revHzb = 1;

    return `مراجعة الربع ${q1} والربع ${q2} من الحزب ${hzb1} 👈 قصادهم مراجعة الحزب ${revHzb}`;
  };

  const getTodayString = () => {
    let today = new Date();
    return `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
  };

  const completeDay = async () => {
    if (currentDay <= 120) {
      const todayStr = getTodayString();
      const dateDisplay = getDateForDay(currentDay);

      const newHistory = [...history, { day: currentDay, date: dateDisplay, task: getTaskForDay(currentDay), status: 'completed' }];
      const nextDay = currentDay + 1;

      setHistory(newHistory);
      setCurrentDay(nextDay);
      setLastCompletedDate(todayStr);

      await AsyncStorage.setItem('quran_history', JSON.stringify(newHistory));
      await AsyncStorage.setItem('quran_day', String(nextDay));
      await AsyncStorage.setItem('quran_last_date', todayStr);

      Alert.alert('نجاح', 'ما شاء الله! تم تسجيل الإنجاز بنجاح 👍');
    }
  };

  const skipDay = async () => {
    if (currentDay <= 120) {
      Alert.alert(
        'تأكيد العجز',
        'هل أنت تأكيد من تسجيل هذا اليوم كعجز/لم يتم تسميعه؟',
        [
          { text: 'إلغاء', style: 'cancel' },
          {
            text: 'تأكيد',
            onPress: async () => {
              const todayStr = getTodayString();
              const dateDisplay = getDateForDay(currentDay);

              const newHistory = [...history, { day: currentDay, date: dateDisplay, task: getTaskForDay(currentDay), status: 'skipped' }];
              const nextDay = currentDay + 1;

              setHistory(newHistory);
              setCurrentDay(nextDay);
              setLastCompletedDate(todayStr);

              await AsyncStorage.setItem('quran_history', JSON.stringify(newHistory));
              await AsyncStorage.setItem('quran_day', String(nextDay));
              await AsyncStorage.setItem('quran_last_date', todayStr);

              Alert.alert('تم التحديث', 'تم تسجيل اليوم ضمن العجز.');
            }
          }
        ]
      );
    }
  };

  const resetAppData = () => {
    Alert.alert(
      'إعادة ضبط',
      'هل تريد مسح تجاربك وتصفير التطبيق ليبدأ من اليوم الأول مجدداً؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تصفير',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.multiRemove(['quran_day', 'quran_last_date', 'quran_history']);
            setCurrentDay(1);
            setLastCompletedDate('');
            setHistory([]);
            Alert.alert('تم', 'تم إعادة ضبط التطبيق بنجاح!');
          }
        }
      ]
    );
  };

  const completed = history.filter(h => h.status === 'completed').length;
  const skipped = history.filter(h => h.status === 'skipped').length;
  const remaining = Math.max(0, 120 - (completed + skipped));
  const progressPercent = Math.round((completed / 120) * 100);

  const isLocked = !isDemoMode() && lastCompletedDate === getTodayString();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f4f6f8" />

      {isDemoMode() && (
        <View style={styles.demoBanner}>
          <Text style={styles.demoText}>
            🛠️ الوضع التجريبي: يمكنك التجربة بحرية، وسيتم التصفير تلقائياً يوم 6 أكتوبر 2026.
          </Text>
        </View>
      )}

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tabBtn, activeTab === 'fullPlanTab' && styles.activeTabBtn]}
          onPress={() => setActiveTab('fullPlanTab')}>
          <Text style={[styles.tabBtnText, activeTab === 'fullPlanTab' && styles.activeTabText]}>📅 الخطة بالتاريخ</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabBtn, activeTab === 'planTab' && styles.activeTabBtn]}
          onPress={() => setActiveTab('planTab')}>
          <Text style={[styles.tabBtnText, activeTab === 'planTab' && styles.activeTabText]}>📖 الورد اليومي</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabBtn, activeTab === 'sheetTab' && styles.activeTabBtn]}
          onPress={() => setActiveTab('sheetTab')}>
          <Text style={[styles.tabBtnText, activeTab === 'sheetTab' && styles.activeTabText]}>📊 السجل والتقدم</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {activeTab === 'planTab' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📖 خطة تثبيت القرآن الكريم</Text>
            <View style={styles.dayBadge}>
              <Text style={styles.dayBadgeText}>
                {currentDay > 120 ? '🎉 تم ختم الخطة' : `اليوم ${currentDay} (${getDateForDay(currentDay)})`}
              </Text>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>✨ الورد المطلوب اليوم:</Text>
              <Text style={styles.sectionDesc}>{getTaskForDay(currentDay)}</Text>
            </View>

            <View style={[styles.section, styles.sectionNext]}>
              <Text style={[styles.sectionTitle, { color: '#b7791f' }]}>📌 معاينة ورد الغد:</Text>
              <Text style={styles.sectionDesc}>{getTaskForDay(currentDay + 1)}</Text>
            </View>

            <TouchableOpacity
              style={[styles.actionBtn, isLocked && styles.disabledBtn]}
              disabled={isLocked}
              onPress={completeDay}>
              <Text style={styles.btnText}>
                {isDemoMode()
                  ? '✔️ تجربة إنجاز ورد اليوم (وضع تجريبي)'
                  : isLocked
                  ? '🔒 تم تسجيل حالة اليوم (ينفك 12:00 ص)'
                  : '✔️ تم إنجاز ورد اليوم'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.skipBtn, isLocked && styles.disabledSkipBtn]}
              disabled={isLocked}
              onPress={skipDay}>
              <Text style={styles.btnText}>⚠️️ لم أسمع ورد اليوم (تسجيل عجز)</Text>
            </TouchableOpacity>

            <View style={styles.stats}>
              <View style={styles.statBox}>
                <Text style={styles.statLabel}>المكتملة</Text>
                <Text style={[styles.statValue, { color: '#2d6a4f' }]}>{completed}</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={styles.statLabel}>العجز</Text>
                <Text style={[styles.statValue, { color: '#e76f51' }]}>{skipped}</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={styles.statLabel}>المتبقي</Text>
                <Text style={[styles.statValue, { color: '#6c757d' }]}>{remaining}</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.resetBtn} onPress={resetAppData}>
              <Text style={styles.resetBtnText}>🔄 إعادة ضبط البيانات / تصفير التجربة</Text>
            </TouchableOpacity>
          </View>
        )}

        {activeTab === 'fullPlanTab' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📅 الخطة الكاملة (120 يوماً)</Text>
            <Text style={{ fontSize: 13, color: '#666', textAlign: 'center', marginBottom: 15 }}>البداية الرسمية: 06/10/2026</Text>
            {Array.from({ length: 120 }, (_, i) => i + 1).map((day) => {
              const record = history.find(h => h.day === day);
              return (
                <View key={day} style={[styles.planItem, day === currentDay && styles.activePlanItem]}>
                  <Text style={styles.planItemTitle}>
                    اليوم {day} - {getDateForDay(day)}
                    {record?.status === 'completed' ? ' (مكتمل ✔️)' : record?.status === 'skipped' ? ' (عجز ⚠️)' : ''}
                  </Text>
                  <Text style={styles.planItemDesc}>{getTaskForDay(day)}</Text>
                </View>
              );
            })}
          </View>
        )}

        {activeTab === 'sheetTab' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📊 رسم بياني ومستوى التقدم</Text>
            <View style={styles.chartBox}>
              <Text style={{ fontWeight: 'bold', color: '#1b4332', fontSize: 15, textAlign: 'center' }}>
                📈 نسبة الإنجاز الكلية: {progressPercent}%
              </Text>
            </View>

            <Text style={{ textAlign: 'right', color: '#1b4332', fontSize: 16, marginTop: 15, fontWeight: 'bold' }}>📜 سجل الأيام:</Text>
            {history.length === 0 ? (
              <Text style={{ textAlign: 'center', padding: 15, color: '#777' }}>لا يوجد أوراد مسجلة بعد.</Text>
            ) : (
              [...history].reverse().map((item, index) => (
                <View key={index} style={styles.historyItem}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: 'bold' }}>اليوم {item.day} ({item.date})</Text>
                    <Text style={{ color: '#2d6a4f', fontSize: 13 }}>{item.task}</Text>
                  </View>
                  <Text style={{ fontWeight: 'bold', color: item.status === 'completed' ? 'green' : '#e76f51' }}>
                    {item.status === 'completed' ? '✔️ مكتمل' : '⚠️ عجز'}
                  </Text>
                </View>
              ))
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f4f6f8' },
  content: { padding: 15 },
  demoBanner: { backgroundColor: '#fff3cd', padding: 10, borderRadius: 8, marginBottom: 12 },
  demoText: { color: '#856404', fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
  tabs: { flexDirection: 'row', backgroundColor: '#e0e0e0', borderRadius: 10, padding: 4, marginHorizontal: 15, marginTop: 10 },
  tabBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 8 },
  activeTabBtn: { backgroundColor: '#2d6a4f' },
  tabBtnText: { fontSize: 12, fontWeight: 'bold', color: '#555' },
  activeTabText: { color: 'white' },
  card: { backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 15 },
  cardTitle: { color: '#1b4332', fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginBottom: 10 },
  dayBadge: { backgroundColor: '#2d6a4f', paddingVertical: 6, paddingHorizontal: 18, borderRadius: 20, alignSelf: 'center', marginBottom: 15 },
  dayBadgeText: { color: 'white', fontWeight: 'bold' },
  section: { backgroundColor: '#f8f9fa', borderRightWidth: 4, borderRightColor: '#2d6a4f', padding: 12, marginVertical: 6, borderRadius: 6 },
  sectionNext: { borderRightColor: '#e9c46a', backgroundColor: '#fffdf5' },
  sectionTitle: { fontWeight: 'bold', color: '#1b4332', marginBottom: 5, textAlign: 'right' },
  sectionDesc: { fontSize: 14, color: '#444', textAlign: 'right' },
  actionBtn: { backgroundColor: '#2d6a4f', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 10 },
  skipBtn: { backgroundColor: '#e76f51', padding: 10, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  disabledBtn: { backgroundColor: '#6c757d' },
  disabledSkipBtn: { backgroundColor: '#cccccc' },
  btnText: { color: 'white', fontWeight: 'bold', fontSize: 14 },
  stats: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 },
  statBox: { backgroundColor: '#f8f9fa', borderWidth: 1, borderColor: '#ddd', padding: 10, borderRadius: 8, flex: 1, marginHorizontal: 2, alignItems: 'center' },
  statLabel: { fontSize: 11, color: '#555' },
  statValue: { fontSize: 18, fontWeight: 'bold', marginTop: 4 },
  resetBtn: { marginTop: 15, padding: 8, borderWidth: 1, borderColor: '#d9534f', borderRadius: 6, alignItems: 'center' },
  resetBtnText: { color: '#d9534f', fontSize: 12 },
  planItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#eee' },
  activePlanItem: { backgroundColor: '#e8f5e9', borderRightWidth: 4, borderRightColor: '#2d6a4f' },
  planItemTitle: { fontWeight: 'bold', textAlign: 'right' },
  planItemDesc: { color: '#555', fontSize: 13, textAlign: 'right', marginTop: 4 },
  historyItem: { padding: 10, borderBottomWidth: 1, borderBottomColor: '#eee', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  chartBox: { backgroundColor: '#f8f9fa', borderRadius: 10, padding: 15, borderWidth: 1, borderColor: '#e0e0e0' }
});

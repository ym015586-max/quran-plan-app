خطة تثبيت القرآن - Expo React Native

المشروع مجهز ليتم بناء APK من خلال Expo/EAS.

الخطوة التالية:
1) ارفع هذا المشروع إلى Expo/Replit أو استخدم بيئة Node/Expo.
2) ثبّت dependencies.
3) شغّل EAS Build بنمط preview للحصول على APK.

ملاحظة:
الكود الأصلي محفوظ في App.js مع تجهيز ملفات المشروع اللازمة.
